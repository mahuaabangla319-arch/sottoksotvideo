# SOT TOK Android APK starter

This package contains:
- `www/index.html` — two-screen launch flow using the exact two images supplied by the user.
- `www/assets/` — splash and welcome artwork.
- `android-shell/` — Capacitor Android wrapper.
- `.github/workflows/android-release.yml` — GitHub Actions workflow that builds a debug APK.

## Important
The Welcome screen's button opens the existing SOT TOK feed URL. It does not implement Google OAuth itself; the existing website must handle login. This wrapper does not copy the old Lovable site's source code, user accounts, videos, or database into the APK. The feed still depends on the old website being online.

## Add to the existing GitHub repository
Upload the contents of this ZIP into the ROOT of the `sottoksotvideo` repository, preserving folders:
- `.github/workflows/android-release.yml`
- `www/`
- `android-shell/`

Do not upload the ZIP file itself as a single file. Do not replace or delete existing `src`, `public`, `drizzle`, or other project files.
If GitHub already contains a `.github/workflows/blank.yml` created during setup, delete that empty/unneeded workflow after confirming this new workflow is present.

## Build
GitHub repository → Actions → `SOT TOK Android APK` → Run workflow.
When complete, open the successful run → Artifacts → `SOT-TOK-APK` → download and extract the APK.

## Current scope and testing
This is a basic WebView wrapper / launch-screen prototype. The Continue button opens the existing website. Test sign-in, video playback, camera, microphone, upload, download, back navigation and Google OAuth on a real Android device. Some site features may require a fuller Capacitor integration and native permission handling.
