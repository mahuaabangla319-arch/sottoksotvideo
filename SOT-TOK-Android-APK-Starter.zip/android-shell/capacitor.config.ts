import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'app.sottok.mobile',
  appName: 'SOT TOK',
  webDir: '../www',
  server: {
    allowNavigation: ['sottoksotvideo.lovable.app']
  },
  android: {
    allowMixedContent: false,
    backgroundColor: '#ffffff'
  }
};
export default config;
