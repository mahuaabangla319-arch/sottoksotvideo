import { useState } from 'react'
import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { supabase } from '@/integrations/supabase/client'

export const Route = createFileRoute('/login')({ component: Login })

function Login() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [mode, setMode] = useState<'signin' | 'signup'>('signin')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setMessage('')
    setBusy(true)
    try {
      if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { full_name: fullName.trim() } },
        })
        if (error) throw error
        if (!data.session) {
          setMessage('অ্যাকাউন্ট তৈরি হয়েছে। ইমেইলে পাঠানো confirmation link খুলে তারপর লগইন করুন।')
          setMode('signin')
          return
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password })
        if (error) throw error
      }
      await navigate({ to: '/feed' })
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'লগইন করা যায়নি। আবার চেষ্টা করুন।')
    } finally {
      setBusy(false)
    }
  }

  const googleSignIn = async () => {
    setMessage('')
    setBusy(true)
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: { redirectTo: `${window.location.origin}/feed` },
      })
      if (error) throw error
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Google দিয়ে লগইন করা যায়নি।')
      setBusy(false)
    }
  }

  return (
    <main style={{ background: '#050505', color: '#fff', minHeight: '100vh', padding: 24, display: 'flex', justifyContent: 'center' }}>
      <section style={{ width: '100%', maxWidth: 420, paddingTop: 48 }}>
        <h1 style={{ textAlign: 'center', fontSize: 36, fontWeight: 900, background: 'linear-gradient(45deg,#ff0050,#a855f7)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>SOT TOK</h1>
        <p style={{ textAlign: 'center', color: '#ccc', marginTop: 8 }}>বাংলা শর্ট ভিডিও অ্যাপ</p>
        <div style={{ display: 'flex', gap: 8, marginTop: 32 }}>
          <button type="button" onClick={() => { setMode('signin'); setMessage('') }} style={tabStyle(mode === 'signin')}>লগইন</button>
          <button type="button" onClick={() => { setMode('signup'); setMessage('') }} style={tabStyle(mode === 'signup')}>নতুন অ্যাকাউন্ট</button>
        </div>
        <form onSubmit={submit} style={{ marginTop: 18 }}>
          {mode === 'signup' && <input required value={fullName} onChange={e => setFullName(e.target.value)} placeholder="আপনার পুরো নাম" autoComplete="name" style={inputStyle} />}
          <input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Gmail / ইমেইল" autoComplete="email" style={inputStyle} />
          <input required minLength={6} type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)" autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} style={inputStyle} />
          <button disabled={busy} type="submit" style={{ ...primaryStyle, opacity: busy ? .65 : 1 }}>{busy ? 'অপেক্ষা করুন…' : mode === 'signup' ? 'অ্যাকাউন্ট তৈরি করুন' : 'লগইন করুন'}</button>
        </form>
        <button disabled={busy} type="button" onClick={googleSignIn} style={googleStyle}>G&nbsp; Google দিয়ে চালিয়ে যান</button>
        {message && <p role="status" style={{ color: '#ffd166', background: '#211b10', padding: 12, borderRadius: 10, marginTop: 16, lineHeight: 1.5 }}>{message}</p>}
        <p style={{ textAlign: 'center', color: '#888', fontSize: 12, marginTop: 28 }}>Privacy Policy • Terms of Service</p>
      </section>
    </main>
  )
}

const inputStyle: React.CSSProperties = { width: '100%', padding: 14, marginTop: 12, borderRadius: 10, background: '#202020', color: '#fff', border: '1px solid #383838', boxSizing: 'border-box' }
const primaryStyle: React.CSSProperties = { width: '100%', padding: 14, marginTop: 16, borderRadius: 10, background: '#2a4bff', color: '#fff', border: 0, fontWeight: 700 }
const googleStyle: React.CSSProperties = { ...primaryStyle, background: '#fff', color: '#171717', marginTop: 12 }
const tabStyle = (active: boolean): React.CSSProperties => ({ flex: 1, padding: 12, borderRadius: 10, border: active ? '1px solid #2a4bff' : '1px solid #444', background: active ? '#17245c' : '#171717', color: '#fff', fontWeight: 700 })
